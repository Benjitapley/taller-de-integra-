"""Connection service package."""
