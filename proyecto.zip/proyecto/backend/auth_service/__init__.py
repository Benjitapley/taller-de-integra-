"""Authentication service package."""
